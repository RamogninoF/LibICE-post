"""
@author: F. Ramognino       <federico.ramognino@polimi.it>
Last update:        9/03/2023

...
"""

from .laminarFlameSpeedModel import laminarFlameSpeedModel
from .tabulatedLFS import tabulatedLFS
